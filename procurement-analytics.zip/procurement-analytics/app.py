from flask import Flask, request, jsonify, send_file, render_template
# ... rest of your imports ...

app = Flask(__name__)

# ... your existing configuration and helper functions ...

@app.route('/')
def index():
    return render_template('index.html')

# ... rest of your existing routes and functions ...

if __name__ == '__main__':
    app.run(debug=True, port=5000)